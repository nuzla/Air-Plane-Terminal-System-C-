﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Drawing;

namespace Nuzi
{
    class Buffer
    {
        
            

        private AeroPlane aeroplane;
        private bool empty = true;

        public void Read(ref AeroPlane aeroplane)
        {
            lock (this)
            {
                // Check whether the buffer is empty.
                if (empty)
                    Monitor.Wait(this);
                empty = true;
                aeroplane = this.aeroplane;
                Monitor.Pulse(this);
            }
        }

      
        
        public void Write(AeroPlane aeroplane)
        {
            lock (this)
            {
                // Check whether the buffer is full.

                if (!empty)
                    Monitor.Wait(this);
                empty = false;
                this.aeroplane = aeroplane;
                Monitor.Pulse(this);
            }
        }

        
             

            }
        }













    

