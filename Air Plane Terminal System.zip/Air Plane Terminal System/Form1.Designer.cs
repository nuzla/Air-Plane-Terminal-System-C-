﻿namespace Nuzi
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.pnl4 = new System.Windows.Forms.Panel();
            this.pnl5 = new System.Windows.Forms.Panel();
            this.pnl6 = new System.Windows.Forms.Panel();
            this.pnl10 = new System.Windows.Forms.Panel();
            this.pnl2 = new System.Windows.Forms.Panel();
            this.pnl7 = new System.Windows.Forms.Panel();
            this.pnl1 = new System.Windows.Forms.Panel();
            this.pnl8 = new System.Windows.Forms.Panel();
            this.pnl3 = new System.Windows.Forms.Panel();
            this.btn1 = new System.Windows.Forms.Button();
            this.btn4 = new System.Windows.Forms.Button();
            this.btn3 = new System.Windows.Forms.Button();
            this.btn2 = new System.Windows.Forms.Button();
            this.pnl9 = new System.Windows.Forms.Panel();
            this.rb2 = new System.Windows.Forms.RadioButton();
            this.rb3 = new System.Windows.Forms.RadioButton();
            this.rb4 = new System.Windows.Forms.RadioButton();
            this.lbl2 = new System.Windows.Forms.Label();
            this.lbl3 = new System.Windows.Forms.Label();
            this.lbl4 = new System.Windows.Forms.Label();
            this.radioButton1 = new System.Windows.Forms.RadioButton();
            this.label1 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // pnl4
            // 
            this.pnl4.BackColor = System.Drawing.Color.Yellow;
            this.pnl4.Location = new System.Drawing.Point(44, 156);
            this.pnl4.Name = "pnl4";
            this.pnl4.Size = new System.Drawing.Size(153, 49);
            this.pnl4.TabIndex = 0;
            // 
            // pnl5
            // 
            this.pnl5.BackColor = System.Drawing.Color.Yellow;
            this.pnl5.Location = new System.Drawing.Point(193, 156);
            this.pnl5.Name = "pnl5";
            this.pnl5.Size = new System.Drawing.Size(156, 49);
            this.pnl5.TabIndex = 1;
            // 
            // pnl6
            // 
            this.pnl6.BackColor = System.Drawing.Color.Yellow;
            this.pnl6.Location = new System.Drawing.Point(346, 156);
            this.pnl6.Name = "pnl6";
            this.pnl6.Size = new System.Drawing.Size(138, 49);
            this.pnl6.TabIndex = 3;
            // 
            // pnl10
            // 
            this.pnl10.BackColor = System.Drawing.Color.Yellow;
            this.pnl10.Location = new System.Drawing.Point(543, 317);
            this.pnl10.Name = "pnl10";
            this.pnl10.Size = new System.Drawing.Size(85, 47);
            this.pnl10.TabIndex = 4;
            // 
            // pnl2
            // 
            this.pnl2.BackColor = System.Drawing.Color.Yellow;
            this.pnl2.Location = new System.Drawing.Point(193, 60);
            this.pnl2.Name = "pnl2";
            this.pnl2.Size = new System.Drawing.Size(55, 100);
            this.pnl2.TabIndex = 5;
            // 
            // pnl7
            // 
            this.pnl7.BackColor = System.Drawing.Color.Yellow;
            this.pnl7.Location = new System.Drawing.Point(44, 203);
            this.pnl7.Name = "pnl7";
            this.pnl7.Size = new System.Drawing.Size(52, 120);
            this.pnl7.TabIndex = 6;
            // 
            // pnl1
            // 
            this.pnl1.BackColor = System.Drawing.Color.Yellow;
            this.pnl1.Location = new System.Drawing.Point(44, 60);
            this.pnl1.Name = "pnl1";
            this.pnl1.Size = new System.Drawing.Size(59, 100);
            this.pnl1.TabIndex = 7;
            // 
            // pnl8
            // 
            this.pnl8.BackColor = System.Drawing.Color.Yellow;
            this.pnl8.Location = new System.Drawing.Point(482, 156);
            this.pnl8.Name = "pnl8";
            this.pnl8.Size = new System.Drawing.Size(62, 167);
            this.pnl8.TabIndex = 8;
            this.pnl8.Paint += new System.Windows.Forms.PaintEventHandler(this.pnl8_Paint);
            // 
            // pnl3
            // 
            this.pnl3.BackColor = System.Drawing.Color.Yellow;
            this.pnl3.Location = new System.Drawing.Point(346, 60);
            this.pnl3.Name = "pnl3";
            this.pnl3.Size = new System.Drawing.Size(53, 100);
            this.pnl3.TabIndex = 9;
            // 
            // btn1
            // 
            this.btn1.BackColor = System.Drawing.Color.Red;
            this.btn1.Location = new System.Drawing.Point(44, 21);
            this.btn1.Name = "btn1";
            this.btn1.Size = new System.Drawing.Size(59, 42);
            this.btn1.TabIndex = 10;
            this.btn1.UseVisualStyleBackColor = false;
            this.btn1.Click += new System.EventHandler(this.btn1_Click);
            // 
            // btn4
            // 
            this.btn4.BackColor = System.Drawing.Color.Blue;
            this.btn4.Location = new System.Drawing.Point(624, 317);
            this.btn4.Name = "btn4";
            this.btn4.Size = new System.Drawing.Size(59, 47);
            this.btn4.TabIndex = 11;
            this.btn4.UseVisualStyleBackColor = false;
            this.btn4.Click += new System.EventHandler(this.btn4_Click);
            // 
            // btn3
            // 
            this.btn3.BackColor = System.Drawing.Color.Red;
            this.btn3.Location = new System.Drawing.Point(346, 21);
            this.btn3.Name = "btn3";
            this.btn3.Size = new System.Drawing.Size(53, 42);
            this.btn3.TabIndex = 12;
            this.btn3.UseVisualStyleBackColor = false;
            this.btn3.Click += new System.EventHandler(this.btn3_Click);
            // 
            // btn2
            // 
            this.btn2.BackColor = System.Drawing.Color.Red;
            this.btn2.Location = new System.Drawing.Point(190, 21);
            this.btn2.Name = "btn2";
            this.btn2.Size = new System.Drawing.Size(58, 42);
            this.btn2.TabIndex = 13;
            this.btn2.UseVisualStyleBackColor = false;
            this.btn2.Click += new System.EventHandler(this.btn2_Click);
            // 
            // pnl9
            // 
            this.pnl9.BackColor = System.Drawing.Color.Yellow;
            this.pnl9.Location = new System.Drawing.Point(1, 317);
            this.pnl9.Name = "pnl9";
            this.pnl9.Size = new System.Drawing.Size(543, 47);
            this.pnl9.TabIndex = 15;
            // 
            // rb2
            // 
            this.rb2.AutoSize = true;
            this.rb2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.rb2.Location = new System.Drawing.Point(597, 203);
            this.rb2.Name = "rb2";
            this.rb2.Size = new System.Drawing.Size(14, 13);
            this.rb2.TabIndex = 17;
            this.rb2.UseVisualStyleBackColor = false;
            // 
            // rb3
            // 
            this.rb3.AutoSize = true;
            this.rb3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.rb3.Location = new System.Drawing.Point(597, 236);
            this.rb3.Name = "rb3";
            this.rb3.Size = new System.Drawing.Size(14, 13);
            this.rb3.TabIndex = 18;
            this.rb3.UseVisualStyleBackColor = false;
            // 
            // rb4
            // 
            this.rb4.AutoSize = true;
            this.rb4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.rb4.Location = new System.Drawing.Point(597, 272);
            this.rb4.Name = "rb4";
            this.rb4.Size = new System.Drawing.Size(14, 13);
            this.rb4.TabIndex = 19;
            this.rb4.UseVisualStyleBackColor = false;
            // 
            // lbl2
            // 
            this.lbl2.AutoSize = true;
            this.lbl2.Location = new System.Drawing.Point(636, 203);
            this.lbl2.Name = "lbl2";
            this.lbl2.Size = new System.Drawing.Size(13, 13);
            this.lbl2.TabIndex = 21;
            this.lbl2.Text = "1";
            // 
            // lbl3
            // 
            this.lbl3.AutoSize = true;
            this.lbl3.Location = new System.Drawing.Point(636, 236);
            this.lbl3.Name = "lbl3";
            this.lbl3.Size = new System.Drawing.Size(13, 13);
            this.lbl3.TabIndex = 22;
            this.lbl3.Text = "2";
            // 
            // lbl4
            // 
            this.lbl4.AutoSize = true;
            this.lbl4.Location = new System.Drawing.Point(636, 272);
            this.lbl4.Name = "lbl4";
            this.lbl4.Size = new System.Drawing.Size(13, 13);
            this.lbl4.TabIndex = 23;
            this.lbl4.Text = "3";
            // 
            // radioButton1
            // 
            this.radioButton1.AutoSize = true;
            this.radioButton1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.radioButton1.Checked = true;
            this.radioButton1.Location = new System.Drawing.Point(597, 167);
            this.radioButton1.Name = "radioButton1";
            this.radioButton1.Size = new System.Drawing.Size(14, 13);
            this.radioButton1.TabIndex = 24;
            this.radioButton1.TabStop = true;
            this.radioButton1.UseVisualStyleBackColor = false;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(636, 167);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(44, 13);
            this.label1.TabIndex = 25;
            this.label1.Text = "Takeoff";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoValidate = System.Windows.Forms.AutoValidate.EnableAllowFocusChange;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.ClientSize = new System.Drawing.Size(953, 475);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.radioButton1);
            this.Controls.Add(this.lbl4);
            this.Controls.Add(this.lbl3);
            this.Controls.Add(this.lbl2);
            this.Controls.Add(this.rb4);
            this.Controls.Add(this.rb3);
            this.Controls.Add(this.rb2);
            this.Controls.Add(this.pnl9);
            this.Controls.Add(this.pnl8);
            this.Controls.Add(this.btn2);
            this.Controls.Add(this.btn3);
            this.Controls.Add(this.btn4);
            this.Controls.Add(this.btn1);
            this.Controls.Add(this.pnl3);
            this.Controls.Add(this.pnl1);
            this.Controls.Add(this.pnl7);
            this.Controls.Add(this.pnl2);
            this.Controls.Add(this.pnl10);
            this.Controls.Add(this.pnl6);
            this.Controls.Add(this.pnl5);
            this.Controls.Add(this.pnl4);
            this.Name = "Form1";
            this.Text = "Form";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel pnl4;
        private System.Windows.Forms.Panel pnl5;
        private System.Windows.Forms.Panel pnl6;
        private System.Windows.Forms.Panel pnl10;
        private System.Windows.Forms.Panel pnl2;
        private System.Windows.Forms.Panel pnl7;
        private System.Windows.Forms.Panel pnl1;
        private System.Windows.Forms.Panel pnl8;
        private System.Windows.Forms.Panel pnl3;
        private System.Windows.Forms.Button btn1;
        private System.Windows.Forms.Button btn4;
        private System.Windows.Forms.Button btn3;
        private System.Windows.Forms.Button btn2;
        private System.Windows.Forms.Panel pnl9;
        private System.Windows.Forms.RadioButton rb2;
        private System.Windows.Forms.RadioButton rb3;
        private System.Windows.Forms.RadioButton rb4;
        private System.Windows.Forms.Label lbl2;
        private System.Windows.Forms.Label lbl3;
        private System.Windows.Forms.Label lbl4;
        private System.Windows.Forms.RadioButton radioButton1;
        private System.Windows.Forms.Label label1;
    }
}

