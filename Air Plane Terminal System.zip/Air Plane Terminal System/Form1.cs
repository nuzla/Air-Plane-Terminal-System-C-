﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Threading;

namespace Nuzi
{
    public partial class Form1 : Form
    {
        public enum Direction
        {
            NS, SN, WE, EW

        }

        class ExtendedSectionThread
        {







            protected Point origin;
            protected int delay;
            protected Panel panel;
            protected Direction direction;
            protected Color colour;
            protected AeroPlane aeroplane;
            protected Point plane;

            protected int xDelta;
            protected int yDelta;
            protected Semaphore readSemaphore;
            protected Semaphore writeSemaphore;
            protected Buffer readBuffer;
            protected bool locked = true;
            protected Buffer writeBuffer;
            protected int panelNum;




            public ExtendedSectionThread(Point origin, int delay, Direction direction, Panel panel, Color colour, Semaphore readSemaphore, Semaphore writeSemaphore, Buffer readBuffer, Buffer writeBuffer, int panelNum)
            {
                this.origin = origin;
                this.delay = delay;
                this.direction = direction;
                this.panel = panel;


                this.colour = colour;
                this.plane = origin;
                this.panel.Paint += new PaintEventHandler(this.panel_Paint);

                this.readSemaphore = readSemaphore;
                this.writeSemaphore = writeSemaphore;
                this.readBuffer = readBuffer;
                this.writeBuffer = writeBuffer;

                this.panelNum = panelNum;

                updateDeltas(direction);

            }

            private void updateDeltas(Direction direction)
            {
                switch (direction)
                {

                    case Direction.NS: this.yDelta = +5;
                        this.xDelta = 0;
                        break;
                    case Direction.SN:
                        this.yDelta = -5;
                        this.xDelta = 0;
                        break;
                    case Direction.EW: this.yDelta = 0;
                        this.xDelta = -10; break;
                    case Direction.WE: this.yDelta = 0;
                        this.xDelta = +5; break;



                }
            }




            public void Start()
            {
                while (true)
                {
                    this.colour = Color.Yellow;
                    for (int k = 1; k <= 2; k++)
                    {
                       
                        this.zeroPlane();

                       
                        readBuffer.Read(ref this.aeroplane);
                        readSemaphore.Wait();
                     
                        this.colour = this.aeroplane.Color;


                        if ((panelNum == 1 || panelNum == 2 || panelNum == 3) && aeroplane.num != 0)
                        {
                            updateDeltas(Direction.SN);
                            plane.X = 20;
                            plane.Y = 50;
                        }
                        else

                            updateDeltas(direction);

                        if (aeroplane.num == 1 || aeroplane.num == 2 || aeroplane.num == 3)
                            switch (panelNum)
                            {
                                case 1: planeIsInHub1 = true; break;
                                case 2: planeIsInHub2 = true; break;
                                case 3: planeIsInHub3 = true; break;
                            }

                        for (int i = 1; i <= 20; i++)
                        {

                            panel.Invalidate();
                            this.movePlane(xDelta, yDelta);
                            Thread.Sleep(delay);

                        }

                       
                        if (aeroplane.num == 0)
                            switch (panelNum)
                            {
                                case 1: planeIsInHub1 = false; break;
                                case 2: planeIsInHub2 = false; break;
                                case 3: planeIsInHub3 = false; break;
                            }

                        writeSemaphore.Wait();

                        if (!(panelNum == 9 && (this.aeroplane.num == 0)))
                        {

                            if (panelNum == 7 && aeroplane.num == 1)
                            {
                                while (planeIsInHub1)
                                    continue;
                                hub1.Write(this.aeroplane);
                            }
                            else
                                if (panelNum == 4 && aeroplane.num == 2)
                                {
                                    while (planeIsInHub2)
                                        continue;
                                    hub2.Write(this.aeroplane);
                                }
                                else
                                    if (panelNum == 5 && aeroplane.num == 3)
                                    {
                                        while (planeIsInHub3)
                                            continue;
                                        hub3.Write(this.aeroplane);
                                    }
                                    else
                                        if (!((panelNum == 1 || panelNum == 2 || panelNum == 3) && aeroplane.num != 0))
                                            writeBuffer.Write(this.aeroplane);
                        }
                        writeSemaphore.Signal();
                        readSemaphore.Signal();

                        Form1.getForm().updateButtonColors();
                        
                        this.colour = Color.Yellow;
                        panel.Invalidate();

                       


                    }
                    this.colour = Color.Yellow;
                    panel.Invalidate();

                }
            }

            protected void zeroPlane()
            {
                plane.X = origin.X;
                plane.Y = origin.Y;
            }

            protected void movePlane(int xDelta, int yDelta)
            {
                plane.X += xDelta;
                plane.Y += yDelta;
            }


            protected void panel_Paint(object sender, PaintEventArgs e)
            {
                Graphics g = e.Graphics;

                SolidBrush brush = new SolidBrush(colour);

               

                g.FillRectangle(brush, plane.X, plane.Y, 10, 10);



                brush.Dispose();    //  Dispose of graphic
                g.Dispose();        //  resources  
            }




        }

        private ExtendedSectionThread[] sectionThreads = new ExtendedSectionThread[11];
       private Thread[] threads = new Thread[11];
       protected static bool planeIsInHub1=true, planeIsInHub2=true, planeIsInHub3=true;

        private static Buffer hub1,hub2,hub3,arrival;

        public Form1()
        {
            InitializeComponent();

            this.Closing += new CancelEventHandler(this.Form1_Closing);
            
            Buffer buffer1_4_7 = new Buffer();
            Buffer buffer2_4_5 = new Buffer();
            Buffer buffer3_6_8 = new Buffer();
            Buffer buffer7_9 = new Buffer();
            Buffer buff8 = new Buffer();
            Buffer buffer9_10 = new Buffer();
            Buffer buff10 = new Buffer();
            hub1=new Buffer();
            hub2 = new Buffer();
            hub3 = new Buffer();
            arrival = new Buffer();

            Semaphore semaphore1_4_7 = new Semaphore();
            Semaphore semaphore2_4_5 = new Semaphore();
            Semaphore semaphore3_6_8 = new Semaphore();
            Semaphore semaphore7_9 = new Semaphore();
            Semaphore semaphore8 = new Semaphore();
            Semaphore semaphore9_10 = new Semaphore();
            Semaphore semaphore10 = new Semaphore();
            Semaphore semaphorehub1 = new Semaphore();
            Semaphore semaphorehub2 = new Semaphore();
            Semaphore semaphorehub3 = new Semaphore();
            Semaphore semaphorearrival = new Semaphore();
        

           sectionThreads[1] = new ExtendedSectionThread(new Point(20, -10), 50, Direction.NS, pnl1, Color.Red, semaphorehub1, semaphore1_4_7, hub1, buffer1_4_7,1);
           sectionThreads[2] = new ExtendedSectionThread(new Point(20, -10), 50, Direction.NS, pnl2, Color.Red, semaphorehub2, semaphore2_4_5, hub2, buffer2_4_5,2);
           sectionThreads[3] = new ExtendedSectionThread(new Point(20, -10), 50, Direction.NS, pnl3, Color.Red, semaphorehub3, semaphore3_6_8, hub3, buffer3_6_8, 3);
           sectionThreads[4] = new ExtendedSectionThread(new Point(20, 10), 50, Direction.WE, pnl4, Color.Red, semaphore1_4_7,semaphore2_4_5, buffer1_4_7, buffer2_4_5, 4);
           sectionThreads[5] = new ExtendedSectionThread(new Point(20, 10), 50, Direction.WE, pnl5, Color.Red,semaphore2_4_5, semaphore3_6_8, buffer2_4_5, buffer3_6_8, 5);
           sectionThreads[6] = new ExtendedSectionThread(new Point(20, 10), 50, Direction.WE, pnl6, Color.Red, semaphore3_6_8,semaphore8, buffer3_6_8, buff8, 6);
           sectionThreads[8] = new ExtendedSectionThread(new Point(10, 10), 50, Direction.NS, pnl8, Color.Red, semaphore8, semaphore9_10, buff8, buffer9_10, 8);
           sectionThreads[10] = new ExtendedSectionThread(new Point(20, 10), 50, Direction.EW, pnl10, Color.Red, semaphorearrival,semaphore9_10, arrival, buffer9_10, 10);
            sectionThreads[7] = new ExtendedSectionThread(new Point(20,10),50,Direction.SN,pnl7,Color.Red,semaphore7_9,semaphore1_4_7,buffer7_9,buffer1_4_7,7);
            sectionThreads[9] = new ExtendedSectionThread(new Point(400, 10), 50, Direction.EW, pnl9, Color.Red, semaphore9_10,semaphore7_9, buffer9_10, buffer7_9,9);

            

            for (int i = 1; i <= 10;i++ )
                threads[i] = new Thread(new ThreadStart(sectionThreads[i].Start));

            for (int i = 1; i <= 10; i++)
                threads[i].Start();
            

        }


        private void Form1_Closing(object sender, CancelEventArgs e)
        {
            Environment.Exit(Environment.ExitCode);
        }
        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void btn4_Click(object sender, EventArgs e)
        {
            int x;
            if (rb2.Checked)
                x = 1;
            else if (rb3.Checked)
                x = 2;
            else if (rb4.Checked)
                x = 3;
            else
                x =0;
            arrival.Write(new AeroPlane(getColor(), x));
        }

        private void pnl8_Paint(object sender, PaintEventArgs e)
        {

        }
        private Color getColor() {

            Random random = new Random();

            int num = random.Next(10);

            switch (num) { 
                case 1:
                    return Color.Violet;
                case 2:
                    return Color.White;
                case 3:
                    return Color.SlateBlue;
                case 4:
                    return Color.Silver;
                case 5:
                    return Color.Orange;
                case 6:
                    return Color.MistyRose;
                case 7:
                    return Color.Beige;
                case 8:
                    return Color.Black;
                case 9:
                    return
                        Color.Brown;
                default: return Color.Red;
            }
            
        }

        private void btn1_Click(object sender, EventArgs e)
        {
            if (!planeIsInHub1) {
                MessageBox.Show("The hub is empty!");
                return;
            }
            hub1.Write(new AeroPlane(getColor(),0));
            planeIsInHub1 = true;
            updateButtonColors();
        }

        private void btn2_Click(object sender, EventArgs e)
        {
            if (!planeIsInHub2)
            {
                MessageBox.Show("The hub is empty!");
                return;
            }
            hub2.Write(new AeroPlane(getColor(), 0));
                planeIsInHub2=true;
                updateButtonColors();
        }

        private void btn3_Click(object sender, EventArgs e)
        {
            if (!planeIsInHub3)
            {
                MessageBox.Show("The hub is empty!");
                return;
            }
            hub3.Write(new AeroPlane(getColor(), 0));
            planeIsInHub3 = true;
            updateButtonColors();
        }

        private void updateButtonColors(){

            lock (this)
            {
                if (planeIsInHub1)
                    btn1.BackColor = Color.Red;
                else
                    btn1.BackColor = Color.Green;

                if (planeIsInHub2)
                    btn2.BackColor = Color.Red;
                else
                    btn2.BackColor = Color.Green;

                if (planeIsInHub3)
                    btn3.BackColor = Color.Red;
                else
                    btn3.BackColor = Color.Green;
            }
        }

        private static Form1 instance = null;
        public static Form1 getForm() {
            if (instance == null)
                instance = new Form1();
            return instance;
        }

       
    }

}
