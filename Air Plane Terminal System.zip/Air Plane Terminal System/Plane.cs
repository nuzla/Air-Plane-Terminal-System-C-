﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Drawing;
using System.Windows.Forms;

namespace Nuzi
{
    public class AeroPlane
    {

        public Color Color;
        public int num;

        public AeroPlane(Color color) { this.Color = color; }
        public AeroPlane(Color Color, int num)
        {
            this.Color = Color;
            this.num = num;

        }







    }
}
